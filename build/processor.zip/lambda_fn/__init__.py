"""lambda_fn package initializer - makes the folder importable for tests and deployment."""

__all__ = ["processor"]
